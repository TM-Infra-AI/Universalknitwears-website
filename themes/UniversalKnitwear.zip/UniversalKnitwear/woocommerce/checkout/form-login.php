<?php
/**
 * Checkout login form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-login.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you (the theme developer).
 * will need to copy the new files to your theme to maintain compatibility. We try to do this.
 * as little as possible, but it does happen. When this occurs the version of the template file will.
 * be bumped and the readme will list any important changes.
 *
 * @see 	    http://docs.woothemes.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( is_user_logged_in() || 'no' === get_option( 'woocommerce_enable_checkout_login_reminder' ) ) {
	return;
}

$info_message  = apply_filters( 'woocommerce_checkout_login_message', __( 'Returning customer? &nbsp;', 'woocommerce' ) );
$info_message .= ' <a href="#" class="showlogin button checkout-btn">' . __( 'Log In', 'woocommerce' ) . '</a>';
//$info_message .= ' Don\'t have an account yet? <a href="http://bordingweb.com/clients/uKnitwear/my-account/" class="button" style="float: none;">' . __( 'Create an account', 'woocommerce' ) . '</a>';
wc_print_notice( $info_message, 'notice' );
?>

<?php
	woocommerce_login_form(
		array(
			'message'  => __( 'If you have shopped with us before, please enter your details in the boxes below. If you are a new customer, please proceed to the Billing &amp; Shipping section.', 'woocommerce' ),
			'redirect' => wc_get_page_permalink( 'checkout' ),
			'hidden'   => true
		)
	);
?>
<div class="woocommerce">
<div class="woocommerce-info">
	Don't have an account yet?&nbsp;<a href="http://bordingweb.com/clients/uKnitwear/my-account/" class="button checkout-btn" >Register</a>
	</div>
</div>
